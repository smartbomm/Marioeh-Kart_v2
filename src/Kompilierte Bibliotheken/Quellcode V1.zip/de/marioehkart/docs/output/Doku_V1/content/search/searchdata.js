var indexSectionsWithContent =
{
  0: "acfgmrstxy",
  1: "cmrs",
  2: "acfgmt",
  3: "axy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "Alle",
  1: "Klassen",
  2: "Funktionen",
  3: "Variablen"
};

