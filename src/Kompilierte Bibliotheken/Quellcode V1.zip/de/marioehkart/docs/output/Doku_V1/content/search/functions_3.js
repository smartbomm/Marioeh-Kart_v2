var searchData=
[
  ['getcoordinates_0',['getCoordinates',['../classde_1_1marioehkart_1_1marioehkarte_1_1_map.html#a432cac54eae9fb72e51f3556049e0055',1,'de::marioehkart::marioehkarte::Map']]]
];
