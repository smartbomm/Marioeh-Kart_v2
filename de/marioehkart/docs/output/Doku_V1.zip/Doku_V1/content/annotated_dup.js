var annotated_dup =
[
    [ "de", null, [
      [ "marioehkart", null, [
        [ "marioehkarte", null, [
          [ "Coordinates", "classde_1_1marioehkart_1_1marioehkarte_1_1_coordinates.html", "classde_1_1marioehkart_1_1marioehkarte_1_1_coordinates" ],
          [ "Map", "classde_1_1marioehkart_1_1marioehkarte_1_1_map.html", "classde_1_1marioehkart_1_1marioehkarte_1_1_map" ],
          [ "Rail", "classde_1_1marioehkart_1_1marioehkarte_1_1_rail.html", null ],
          [ "Section", "classde_1_1marioehkart_1_1marioehkarte_1_1_section.html", null ]
        ] ]
      ] ]
    ] ]
];