var searchData=
[
  ['transformcoordinates_0',['transformCoordinates',['../classde_1_1marioehkart_1_1marioehkarte_1_1_coordinates.html#a3986ba018fab440596615eec7a5f965a',1,'de::marioehkart::marioehkarte::Coordinates']]]
];
