var classde_1_1marioehkart_1_1marioehkarte_1_1_coordinates =
[
    [ "Coordinates", "classde_1_1marioehkart_1_1marioehkarte_1_1_coordinates.html#ab2e7cfcbb67ffd72387a6fc4a96ee1ef", null ],
    [ "Coordinates", "classde_1_1marioehkart_1_1marioehkarte_1_1_coordinates.html#a79eeef660df6a866162117efcf86e20a", null ],
    [ "angle_x", "classde_1_1marioehkart_1_1marioehkarte_1_1_coordinates.html#a185473ba3f25aedd9bf90dc90d152fdb", null ],
    [ "x", "classde_1_1marioehkart_1_1marioehkarte_1_1_coordinates.html#a659fc1abaa757b14e92f156a162b6dea", null ],
    [ "y", "classde_1_1marioehkart_1_1marioehkarte_1_1_coordinates.html#a54babf3615280c5cec6527678c6408d0", null ]
];